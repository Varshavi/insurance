<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Assignment</title>

    <!-- Include any additional stylesheets or scripts here -->
    <!-- For example: -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> -->
</head>
<body>

    <header>
        <nav>
            <!-- Your navigation bar goes here -->
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="<?php echo e(route('posts.index')); ?>">Posts</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <div class="container">
            <!-- The content of the child view will be placed here -->
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <footer>
        <!-- Your footer content goes here -->
        <p>&copy; <?php echo e(date('Y')); ?> Assignment</p>
    </footer>

    <!-- Include any additional scripts here -->
    <!-- For example: -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script

</body>
</html>
<?php /**PATH C:\xampp\htdocs\your-project-name\resources\views/layouts/app.blade.php ENDPATH**/ ?>