<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class InsuranceController extends Controller
{
    public function showForm()
    {
        return view('insurance.form');
    }

    public function calculatePremium(Request $request)
    {
        $request->validate([
            'pincode' => 'required|string|min:6|max:6',
            'age' => 'required|numeric|min:18',
            'sum_insured' => 'required|in:3,5,7,10',
        ]);

        $tokenResponse = Http::post('https://internal.insurance4life.in/care_token.php', [
            'api_key' => 'SIBL',
        ]);

        $token = $tokenResponse->json()['token'] ?? null;

        if ($token) {
            $premiumResponse = Http::withHeaders([
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json',
            ])->post('https://internal.insurance4life.in/care_quote.php', [
                'partnerId' => '347',
                'abacusId' => '5031',
                'postedField' => [
                    'field_54' => $request->pincode,
                    'field_2' => $request->sum_insured,
                    'field_3' => $this->getAgeBand($request->age),
                ],
            ]);

            $premiumData = $premiumResponse->json();
            $planName = $premiumData['plan_name'] ?? '';
            $premiumAmount = $premiumData['premium_amount'] ?? '';

            return view('insurance.result', compact('planName', 'premiumAmount'));
        } else {
            return back()->with('error', 'Failed to generate API token');
        }
    }

    private function getAgeBand($age)
    {
        $age_band = [
            61 => '61 - 65 years',
            66 => '66 - 70 years',
            71 => '71 - 75 years',
            76 => '> 75 years',
        ];
    
        foreach ($age_band as $upperLimit => $band) {
            if ($age <= $upperLimit) {
                return $band;
            }
        }
    
        return end($age_band);
    }
}
